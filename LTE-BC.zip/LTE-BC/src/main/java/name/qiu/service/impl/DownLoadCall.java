package name.qiu.service.impl;

import java.net.URL;
import java.util.concurrent.Callable;

import name.qiu.utils.HttpTool;

public class DownLoadCall implements Callable<String>{
	
	/**
	 * 待下载的url
	 */
	private URL url;
	
	public DownLoadCall(URL url) {
		this.url = url;
	}

	@Override
	public String call() throws Exception {

		String content = HttpTool.doGet(url);
		
		return content;
	}

	public URL getUrl() {
		return url;
	}

}
